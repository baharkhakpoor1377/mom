SHAHNAMEH BEDTIME STORIES — website folder for Vercel
=====================================================

WHAT IS IN HERE
  index.html      the page (writer name, bio, story titles and summaries live here)
  app.js          the app
  entrance.mp4    the entrance video
  audio/          put the voice recordings here (mp3 or m4a)
  audio/audio.json  tells the app which file belongs to which story
  vercel.json     Vercel settings (leave as is)

PUT ONLINE (Vercel)
  Option A - command line (fastest):
    1. Install Node.js from nodejs.org
    2. In Terminal:  cd to this folder, then run:  npx vercel --prod
    3. Log in, press Enter on every question. You get your live link.
  Option B - GitHub:
    1. Upload this folder's files to a new GitHub repository
    2. On vercel.com choose "Add New > Project", pick the repository, press Deploy.
  To update later: change the files and run the same command again.

ADD A VOICE TO A STORY
  1. Copy the recording into the audio folder, e.g. 1.mp3
  2. Open audio/audio.json - each story number points to its file name
     (1 = Fereydun and the cow, 2 = Rostam and the dragon, 3 = Zahhak,
      4 = Rostam and the White Demon, 5 = Seven Trials, 6 = Rostam and Akvan Div)
  3. Deploy again.
  Keep each file under about 25 MB (a 15-minute mp3 is usually 10-15 MB).

IMPORTANT NOTES
  - The writer's hidden "studio" (add voice/photo/text from inside the app) only works on the
    Claude link. On Vercel, stories and voices are changed by editing these files.
  - Customer accounts are saved on each person's own phone/browser only.
  - Contact details on the Events tickets are placeholders. In index.html find
    "mail":"hello@example.com","ig":"@talesaloud","tg":"t.me/talesaloud","web":"talesaloud.example.com"
    and replace them with the real ones before going live.
